import { useNavigate } from "react-router-dom";
import { ArrowRight, User, Settings, Crown } from "lucide-react";
import { useRole, type Role } from "../context/RoleContext";

function LotusIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <ellipse cx="12" cy="14" rx="4" ry="5" fill="currentColor" opacity="0.9" />
      <ellipse cx="7" cy="13" rx="3" ry="4" transform="rotate(-25 7 13)" fill="currentColor" opacity="0.7" />
      <ellipse cx="17" cy="13" rx="3" ry="4" transform="rotate(25 17 13)" fill="currentColor" opacity="0.7" />
      <ellipse cx="4" cy="11" rx="2.5" ry="3.5" transform="rotate(-45 4 11)" fill="currentColor" opacity="0.4" />
      <ellipse cx="20" cy="11" rx="2.5" ry="3.5" transform="rotate(45 20 11)" fill="currentColor" opacity="0.4" />
      <line x1="12" y1="19" x2="12" y2="22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="12" y1="22" x2="9" y2="22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="12" y1="22" x2="15" y2="22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

interface PortalCardProps {
  badge: string;
  badgeStyle: string;
  icon: React.ElementType;
  iconBg: string;
  iconColor: string;
  title: string;
  description: string;
  buttonLabel: string;
  buttonStyle: string;
  cardStyle: string;
  titleStyle: string;
  descStyle: string;
  role: Role;
  route: string;
}

function PortalCard({
  badge, badgeStyle, icon: Icon, iconBg, iconColor,
  title, description, buttonLabel, buttonStyle,
  cardStyle, titleStyle, descStyle, role, route,
}: PortalCardProps) {
  const { setRole } = useRole();
  const navigate = useNavigate();

  function handleClick() {
    setRole(role);
    navigate(route);
  }

  return (
    <div className={`relative rounded-3xl p-8 flex flex-col gap-6 transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5 ${cardStyle}`}>
      <div className="flex items-start justify-between">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${iconBg}`}>
          <Icon size={22} className={iconColor} />
        </div>
        <span className={`inline-flex items-center rounded-full text-[10px] font-semibold tracking-widest uppercase px-2.5 py-1 border ${badgeStyle}`}>
          {badge}
        </span>
      </div>

      <div className="flex flex-col gap-2">
        <h2 className={`font-display font-bold text-xl tracking-tight ${titleStyle}`}>{title}</h2>
        <p className={`text-sm leading-relaxed ${descStyle}`}>{description}</p>
      </div>

      <div className="mt-auto">
        <button
          onClick={handleClick}
          className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold transition-all duration-200 hover:gap-3 cursor-pointer ${buttonStyle}`}
        >
          {buttonLabel}
          <ArrowRight size={15} />
        </button>
      </div>
    </div>
  );
}

export function LandingPage() {
  return (
    <div className="min-h-screen bg-[#FAF6EF] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-center pt-12 pb-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#1C1815] flex items-center justify-center text-[#E8A33D]">
            <LotusIcon size={20} />
          </div>
          <span className="font-display font-bold text-2xl text-[#2B2420]">
            Dharma<span className="text-[#C9A227]">Sangha</span>
          </span>
        </div>
      </div>

      {/* Hero text */}
      <div className="flex flex-col items-center text-center px-6 pt-14 pb-12">
        <h1 className="font-display font-bold text-5xl md:text-6xl text-[#2B2420] tracking-tight leading-tight max-w-xl">
          Choose your portal
        </h1>
        <p className="mt-4 text-[#8A7F6E] text-lg max-w-sm leading-relaxed">
          Select a workspace to continue to your dashboard
        </p>
      </div>

      {/* Cards */}
      <div className="flex-1 flex items-start justify-center px-6 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl">
          {/* User Portal */}
          <PortalCard
            badge="User Portal"
            badgeStyle="border-[#E8A33D] text-[#E8A33D] bg-transparent"
            icon={User}
            iconBg="bg-[#FDF4E7]"
            iconColor="text-[#E8A33D]"
            title="Sangha Member"
            description="Access teachings, meditation tracking, events, and your community, all in one place."
            buttonLabel="Open Dashboard"
            buttonStyle="bg-[#2B2420] text-[#F5EFE3] hover:bg-[#1C1815]"
            cardStyle="bg-white border border-[#F1E9DA]"
            titleStyle="text-[#2B2420]"
            descStyle="text-[#8A7F6E]"
            role="user"
            route="/user"
          />

          {/* Admin Panel */}
          <PortalCard
            badge="Admin Panel"
            badgeStyle="border-transparent bg-[#E8A33D] text-[#2B2420]"
            icon={Settings}
            iconBg="bg-[#FEF3DC]"
            iconColor="text-[#C98A28]"
            title="Center Admin"
            description="Manage your center's members, teachings, events, and local community activity."
            buttonLabel="Open Panel"
            buttonStyle="bg-[#E8A33D] text-[#2B2420] hover:bg-[#C98A28]"
            cardStyle="bg-[#FDF4E7] border border-[#F1E0B8]"
            titleStyle="text-[#2B2420]"
            descStyle="text-[#7A6A50]"
            role="admin"
            route="/admin"
          />

          {/* Super Admin */}
          <PortalCard
            badge="Super Admin"
            badgeStyle="border-[#C9A227] text-[#C9A227] bg-transparent"
            icon={Crown}
            iconBg="bg-[#2A2018]"
            iconColor="text-[#C9A227]"
            title="Platform Admin"
            description="Oversee all centers, admins, donations, and platform-wide operations."
            buttonLabel="Open Control Center"
            buttonStyle="bg-[#C9A227] text-[#1C1815] hover:bg-[#B08C1E]"
            cardStyle="bg-[#1C1815] border border-[#3A3028]"
            titleStyle="text-[#F5EFE3]"
            descStyle="text-[#8A7F6E]"
            role="super-admin"
            route="/super-admin"
          />
        </div>
      </div>

      <footer className="text-center pb-8 text-[#B8A98C] text-xs">
        © 2024 DharmaSangha · Built with compassion
      </footer>
    </div>
  );
}
