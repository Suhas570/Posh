import { teachings } from "../../data/teachings";
import { ContentCard } from "../../components/ContentCard";
import { Button } from "../../components/Button";

export function AdminContent() {
  const centerTeachings = teachings.filter((t) => t.center === "Bodhi Grove Sangha");
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-3xl text-[#2B2420] tracking-tight">Content Library</h1>
          <p className="text-[#8A7F6E] text-sm mt-1">Bodhi Grove Sangha · {centerTeachings.length} teachings</p>
        </div>
        <Button variant="saffron">Add Teaching</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {teachings.map((t) => (
          <ContentCard
            key={t.id}
            title={t.title}
            typeBadge={t.category}
            meta={[
              { label: "Author", value: t.author },
              { label: "Duration", value: t.duration },
              { label: "Views", value: t.views },
              { label: "Date", value: t.date },
            ]}
            contributors={[t.author]}
            contributorsLabel="Teacher"
            statusBadge={{ label: t.status, variant: t.status === "published" ? "success" : "warning" }}
          />
        ))}
      </div>
    </div>
  );
}
