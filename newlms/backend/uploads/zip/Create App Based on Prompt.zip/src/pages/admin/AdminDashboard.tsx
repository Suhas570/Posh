import { Users, BookOpen, CalendarDays, TrendingUp } from "lucide-react";
import { StatCard } from "../../components/StatCard";
import { events } from "../../data/events";
import { PillBadge } from "../../components/PillBadge";

export function AdminDashboard() {
  const upcoming = events.slice(0, 3);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display font-bold text-3xl text-[#2B2420] tracking-tight">Bodhi Grove Sangha</h1>
        <p className="text-[#8A7F6E] text-sm mt-1">Center dashboard · March 2024</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Members" value="148" sub="2 pending approval" icon={<Users size={18} />} trend={{ value: "5 this month", positive: true }} />
        <StatCard label="Teachings" value="12" sub="Published content" icon={<BookOpen size={18} />} />
        <StatCard label="Upcoming Events" value="3" sub="Next 30 days" icon={<CalendarDays size={18} />} />
        <StatCard label="Donations (Mar)" value="$4,200" sub="Building fund active" icon={<TrendingUp size={18} />} trend={{ value: "8% vs Feb", positive: true }} />
      </div>

      {/* Upcoming events */}
      <div className="bg-white border border-[#F1E9DA] rounded-2xl p-6">
        <h2 className="font-display font-semibold text-base text-[#2B2420] mb-5">Upcoming Events</h2>
        <div className="space-y-3">
          {upcoming.map((ev) => (
            <div key={ev.id} className="flex items-center justify-between py-3 border-b border-[#F9F5EE] last:border-0">
              <div>
                <p className="font-medium text-[#2B2420] text-sm">{ev.title}</p>
                <p className="text-xs text-[#8A7F6E] mt-0.5">{ev.date} · {ev.location}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-[#8A7F6E]">{ev.registrations}/{ev.capacity}</span>
                <PillBadge label={ev.type} variant="muted" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Engagement snapshot */}
      <div className="bg-[#1C1815] border border-[#3A3028] rounded-2xl p-6">
        <h2 className="font-display font-semibold text-base text-[#F5EFE3] mb-5">Engagement Snapshot</h2>
        <div className="grid grid-cols-3 gap-6">
          {[
            { label: "Teaching Views", value: "892", sub: "This month" },
            { label: "Forum Posts", value: "47", sub: "Active discussions" },
            { label: "Course Completions", value: "23", sub: "March 2024" },
          ].map((s) => (
            <div key={s.label}>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-[#8A7F6E] mb-1">{s.label}</p>
              <p className="font-display font-bold text-2xl text-[#E8A33D]">{s.value}</p>
              <p className="text-xs text-[#8A7F6E] mt-0.5">{s.sub}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
