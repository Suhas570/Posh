import { events } from "../../data/events";
import { CalendarDays, MapPin, Users } from "lucide-react";
import { PillBadge } from "../../components/PillBadge";
import { Button } from "../../components/Button";

export function AdminEvents() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-3xl text-[#2B2420] tracking-tight">Events</h1>
          <p className="text-[#8A7F6E] text-sm mt-1">Manage retreats & meditation sessions</p>
        </div>
        <Button variant="saffron">Create Event</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {events.map((ev) => (
          <div key={ev.id} className="bg-white border border-[#F1E9DA] rounded-2xl p-5 hover:shadow-md transition-all duration-200 flex flex-col gap-4">
            <div className="flex items-start justify-between">
              <PillBadge label={ev.type} variant="muted" />
              <PillBadge label={ev.status} variant="success" />
            </div>
            <h3 className="font-display font-bold text-base text-[#2B2420]">{ev.title}</h3>
            <div className="space-y-1.5 text-xs text-[#8A7F6E]">
              <div className="flex items-center gap-2"><CalendarDays size={13} className="text-[#E8A33D]" />{ev.date}</div>
              <div className="flex items-center gap-2"><MapPin size={13} className="text-[#E8A33D]" />{ev.location}</div>
              <div className="flex items-center gap-2"><Users size={13} className="text-[#E8A33D]" />{ev.registrations}/{ev.capacity} registered</div>
            </div>
            <div className="h-1.5 bg-[#F1E9DA] rounded-full overflow-hidden">
              <div className="h-full bg-[#E8A33D] rounded-full" style={{ width: `${(ev.registrations / ev.capacity) * 100}%` }} />
            </div>
            <div className="flex gap-2 mt-auto">
              <button className="flex-1 text-xs font-medium text-[#2B2420] border border-[#F1E9DA] rounded-full py-2 hover:bg-[#F5F0E8] transition-colors cursor-pointer">Edit</button>
              <button className="flex-1 text-xs font-medium text-[#E8A33D] border border-[#E8A33D]/30 rounded-full py-2 hover:bg-[#FDF4E7] transition-colors cursor-pointer">View RSVPs</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
