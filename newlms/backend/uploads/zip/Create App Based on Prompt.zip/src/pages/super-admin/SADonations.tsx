import { DollarSign, TrendingUp, Users, Heart } from "lucide-react";
import { donations, donationStats } from "../../data/donations";
import { StatCard } from "../../components/StatCard";

export function SADonations() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-3xl text-[#2B2420] tracking-tight">Donations & Finance</h1>
        <p className="text-[#8A7F6E] text-sm mt-1">Platform-wide financial overview</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="This Month" value={`$${donationStats.totalThisMonth.toLocaleString()}`} icon={<DollarSign size={18} />} trend={{ value: "12% vs last month", positive: true }} />
        <StatCard label="All Time" value={`$${donationStats.totalAllTime.toLocaleString()}`} icon={<TrendingUp size={18} />} />
        <StatCard label="Avg. Donation" value={`$${donationStats.avgDonation}`} icon={<Heart size={18} />} />
        <StatCard label="Total Donors" value={donationStats.donors} icon={<Users size={18} />} />
      </div>

      <div className="bg-white border border-[#F1E9DA] rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-[#F1E9DA] flex items-center justify-between">
          <h2 className="font-display font-semibold text-[#2B2420]">Recent Donations</h2>
          <button className="text-xs text-[#E8A33D] font-medium hover:underline cursor-pointer">Export CSV</button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[#F1E9DA]">
              {["Donor", "Amount", "Center", "Purpose", "Method", "Date"].map((h) => (
                <th key={h} className="text-left text-[10px] font-semibold uppercase tracking-wider text-[#8A7F6E] px-5 py-3">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {donations.map((d) => (
              <tr key={d.id} className="border-b border-[#F9F5EE] last:border-0 hover:bg-[#FDFAF5] transition-colors">
                <td className="px-5 py-3 font-medium text-[#2B2420]">{d.donor}</td>
                <td className="px-5 py-3 font-semibold text-[#6B8E5A]">${d.amount}</td>
                <td className="px-5 py-3 text-[#8A7F6E]">{d.center.split(" ")[0]}</td>
                <td className="px-5 py-3 text-[#2B2420]">{d.purpose}</td>
                <td className="px-5 py-3 text-[#8A7F6E]">{d.method}</td>
                <td className="px-5 py-3 text-[#8A7F6E]">{d.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
