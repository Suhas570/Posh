import { Phone, Mail, Search } from "lucide-react";
import { admins } from "../../data/admins";
import { PillBadge } from "../../components/PillBadge";
import { Button } from "../../components/Button";

export function SAAdmins() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-3xl text-[#2B2420] tracking-tight">Admin Management</h1>
          <p className="text-[#8A7F6E] text-sm mt-1">{admins.length} admins across all centers</p>
        </div>
        <Button variant="saffron">Add Admin</Button>
      </div>

      <div className="relative max-w-sm">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8A7F6E]" />
        <input
          placeholder="Search admins..."
          className="w-full pl-9 pr-4 py-2 bg-white border border-[#F1E9DA] rounded-full text-sm focus:outline-none focus:border-[#E8A33D] transition-colors"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {admins.map((admin) => (
          <div key={admin.id} className="bg-white border border-[#F1E9DA] rounded-2xl p-5 hover:shadow-md transition-all duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-[#1C1815] text-[#E8A33D] flex items-center justify-center font-display font-bold text-base">
                  {admin.name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                </div>
                <div>
                  <p className="font-semibold text-[#2B2420] text-sm">{admin.name}</p>
                  <p className="text-xs text-[#8A7F6E]">{admin.role}</p>
                </div>
              </div>
              <PillBadge
                label={admin.status}
                variant={admin.status === "active" ? "success" : "danger"}
              />
            </div>

            <div className="space-y-2 mb-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-[#8A7F6E] mb-0.5">Center</p>
                  <p className="text-xs font-medium text-[#2B2420] leading-tight">{admin.center}</p>
                </div>
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-[#8A7F6E] mb-0.5">Since</p>
                  <p className="text-xs font-medium text-[#2B2420]">{admin.since}</p>
                </div>
              </div>
            </div>

            <div className="border-t border-[#F1E9DA] pt-3 flex items-center gap-3">
              <a href={`mailto:${admin.email}`} className="flex items-center gap-1.5 text-xs text-[#8A7F6E] hover:text-[#E8A33D] transition-colors">
                <Mail size={13} /> {admin.email}
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
