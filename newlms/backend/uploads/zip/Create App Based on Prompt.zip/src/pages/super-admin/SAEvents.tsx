import { CalendarDays, MapPin, Users } from "lucide-react";
import { events } from "../../data/events";
import { PillBadge } from "../../components/PillBadge";
import { Button } from "../../components/Button";

const typeColors: Record<string, string> = {
  Retreat: "bg-[#E8F4E3] text-[#6B8E5A]",
  Intensive: "bg-[#FDF4E7] text-[#E8A33D]",
  Ceremony: "bg-[#EAE3F5] text-[#7A2E2E]",
  Orientation: "bg-[#E3EFF5] text-[#2E6B7A]",
  Meditation: "bg-[#F5F0E8] text-[#8A7F6E]",
};

export function SAEvents() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-3xl text-[#2B2420] tracking-tight">Events Calendar</h1>
          <p className="text-[#8A7F6E] text-sm mt-1">Upcoming retreats & events across all centers</p>
        </div>
        <Button variant="saffron">Create Event</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {events.map((ev) => (
          <div key={ev.id} className="bg-white border border-[#F1E9DA] rounded-2xl p-5 hover:shadow-md transition-all duration-200 flex flex-col gap-4">
            <div className="flex items-start justify-between">
              <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full ${typeColors[ev.type] || "bg-[#F5F0E8] text-[#8A7F6E]"}`}>
                {ev.type}
              </span>
              <PillBadge label={ev.status} variant="success" />
            </div>

            <h3 className="font-display font-bold text-base text-[#2B2420] leading-tight">{ev.title}</h3>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs text-[#8A7F6E]">
                <CalendarDays size={13} className="text-[#E8A33D]" />
                <span>{ev.date}{ev.endDate !== ev.date ? ` → ${ev.endDate}` : ""}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-[#8A7F6E]">
                <MapPin size={13} className="text-[#E8A33D]" />
                <span>{ev.location}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-[#8A7F6E]">
                <Users size={13} className="text-[#E8A33D]" />
                <span>{ev.registrations} / {ev.capacity} registered</span>
              </div>
            </div>

            <div className="mt-auto">
              <div className="h-1.5 bg-[#F1E9DA] rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#E8A33D] rounded-full transition-all"
                  style={{ width: `${(ev.registrations / ev.capacity) * 100}%` }}
                />
              </div>
              <p className="text-[10px] text-[#8A7F6E] mt-1">{ev.capacity - ev.registrations} spots remaining</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
