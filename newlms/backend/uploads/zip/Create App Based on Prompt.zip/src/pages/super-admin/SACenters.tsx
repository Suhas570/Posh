import { MapPin, Users, User } from "lucide-react";
import { centers } from "../../data/centers";
import { PillBadge } from "../../components/PillBadge";
import { Button } from "../../components/Button";

export function SACenters() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-3xl text-[#2B2420] tracking-tight">Sangha Centers</h1>
          <p className="text-[#8A7F6E] text-sm mt-1">{centers.length} registered centers</p>
        </div>
        <Button variant="saffron">Add Center</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {centers.map((center) => (
          <div key={center.id} className="bg-white border border-[#F1E9DA] rounded-2xl p-6 hover:shadow-md transition-all duration-200 flex flex-col gap-5">
            <div className="flex items-start justify-between">
              <div className="w-12 h-12 rounded-2xl bg-[#FDF4E7] flex items-center justify-center">
                <span className="text-xl">🏛️</span>
              </div>
              <PillBadge label={center.status} variant="success" />
            </div>

            <div>
              <h3 className="font-display font-bold text-lg text-[#2B2420] leading-tight mb-1">{center.name}</h3>
              <div className="flex items-center gap-1.5 text-xs text-[#8A7F6E]">
                <MapPin size={12} />
                <span>{center.location}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider text-[#8A7F6E] mb-0.5">Head Monk</p>
                <div className="flex items-center gap-1.5">
                  <User size={12} className="text-[#E8A33D]" />
                  <p className="text-xs font-medium text-[#2B2420]">{center.headMonk}</p>
                </div>
              </div>
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider text-[#8A7F6E] mb-0.5">Founded</p>
                <p className="text-xs font-medium text-[#2B2420]">{center.founded}</p>
              </div>
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider text-[#8A7F6E] mb-0.5">Members</p>
                <div className="flex items-center gap-1.5">
                  <Users size={12} className="text-[#E8A33D]" />
                  <p className="text-xs font-medium text-[#2B2420]">{center.memberCount}</p>
                </div>
              </div>
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider text-[#8A7F6E] mb-0.5">Admins</p>
                <p className="text-xs font-medium text-[#2B2420]">{center.adminCount}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
